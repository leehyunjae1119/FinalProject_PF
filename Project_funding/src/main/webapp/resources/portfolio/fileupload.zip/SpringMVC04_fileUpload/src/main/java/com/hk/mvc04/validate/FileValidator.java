package com.hk.mvc04.validate;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Service
public class FileValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return false;
	}

	@Override
	public void validate(Object uploadFile, Errors errors) {
		UploadFile file = (UploadFile) uploadFile;
		
		if(file.getFile().getSize() == 0) {
			errors.rejectValue("file", "uploadForm", 
					"Please select a file");
			
			//field(file)에 대한 errorCode를 리턴,
			//해당 errorCode가 없으면 default message 리턴
		}
	}

}
